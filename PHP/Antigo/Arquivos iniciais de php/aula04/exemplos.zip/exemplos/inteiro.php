<!DOCTYPE html>
<html>
<head>
	<title>Exemplo numeros inteiros</title>
	<meta charset="utf-8">
</head>
<body>
<?php 

	$a=0x1A; //corresponde ao numero decimal 26
	$b= -16;
	$c= $a + $b;
	echo "Resultado $a+$b=$c";
 ?>
</body>
</html>