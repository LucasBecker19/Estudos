<!DOCTYPE html>
<html>
<head>
	<title>Exemplo números reais</title>
	<meta charset="utf-8">
</head>
<body>
<?php 
$preco = 11.90;
$soma=$preco * 4;

?>

<h2>Resultado Final</h2>

<?php 
echo "Quatro revistas custaram R$ $soma";
 ?>

</body>
</html>