<?php 

$n1 =4;
$resultado = $n1/5;

echo $resultado ;

 ?>