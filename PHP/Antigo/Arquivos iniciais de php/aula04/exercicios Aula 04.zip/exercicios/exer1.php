<?php 

$n1 =5;

echo pow($n1,2);


 ?>