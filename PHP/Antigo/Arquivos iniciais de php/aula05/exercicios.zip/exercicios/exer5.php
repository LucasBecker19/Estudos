<?php 
// media aritmetica

$n1 = $_GET['n1'];
$n2 = $_GET['n2'];
$media = ($n1+$n2)/2;

echo "A média dos três números é: $media";

 ?>