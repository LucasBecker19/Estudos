<?php 

$salario = $_GET['salario'];
$imposto = $salario * 0.2;

echo "O imposto a ser pago é: $imposto";



 ?>