<!DOCTYPE html>
<html>
<head>
	<title>Exercício 4</title>
	<meta charset="utf-8">
</head>
<body>
<form method="POST" action="dividir.php">
	<h2>Dividir três números</h2>
	Digite o primeiro número: <input type="text" name="n1" required=""><br>
	Digite o segundo número: <input type="text" name="n2" required=""><br>
	Digite o terceiro número: <input type="text" name="n3" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">
	</form>
</body>
</html>