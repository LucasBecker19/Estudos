<?php 

$nome = $_POST['nome'];
$idade = $_POST['idade'];
$endereco = $_POST['end'];
$email = $_POST['email'];

echo "Dados do Aluno: <br>";
echo "Nome: $nome<br>";
echo "Idade: $idade<br>";
echo "Endereço: $endereco<br>";
echo "E-mail: $email<br>";


 ?>