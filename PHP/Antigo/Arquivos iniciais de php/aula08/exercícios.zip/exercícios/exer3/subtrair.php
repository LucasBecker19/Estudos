<?php 

$n1 = $_POST['n1'];
$n2 = $_POST['n2'];
$n3 = $_POST['n3'];
$subtrair= $n1-$n2-$n3;
echo "A multiplicação dos números $n1-$n2-$n3 é: $subtrair";

 ?>