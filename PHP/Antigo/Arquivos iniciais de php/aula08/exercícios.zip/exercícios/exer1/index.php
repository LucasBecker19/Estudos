<!DOCTYPE html>
<html>
<head>
	<title>Exercício 1</title>
	<meta charset="utf-8">
</head>
<body>
	<form method="post" action="somar.php">
	<h2>Somar três números</h2>
	Digite o primeiro número: <input type="text" name="n1" required=""><br>
	Digite o segundo número: <input type="text" name="n2" required=""><br>
	Digite o terceiro número: <input type="text" name="n3" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">
	<input type="reset" name="btn_apagar" value="Apagar">
	</form>
</body>
</html>