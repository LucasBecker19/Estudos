<!DOCTYPE html>
<html>
<head>
	<title>Exercício 7</title>
	<meta charset="utf-8">
</head>
<body>

<form method="POST" action="calcularimposto.php">
	<h2>Calcular Imposto</h2><br>
	Digite o seu salário: <input type="text" name="salario" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">
	<input type="reset" name="btn_apagar" value="Apagar">
</form>


</body>
</html>