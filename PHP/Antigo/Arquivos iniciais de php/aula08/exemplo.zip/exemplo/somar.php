<?php 

$n1 = $_POST['n1'];
$n2 = $_POST['n1'];
$soma=$n1+$n2;

echo "A soma dos números $n1+$n2 é: $soma";


 ?>