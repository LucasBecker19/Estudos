<!DOCTYPE html>
<html>
<head>
	<title>Exercício 8</title>
   	<meta charset="utf-8">
</head>
<body>
<form method="GET" action="calculadora.php">
	<h2>Calculadora</h2><br>
	Digite o primeiro número: <input type="text" name="n1" required=""><br>
	Digite o segundo número: <input type="text" name="n2" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">
	<input type="reset" name="btn_apagar" value="Apagar">

</form>

</body>
</html>