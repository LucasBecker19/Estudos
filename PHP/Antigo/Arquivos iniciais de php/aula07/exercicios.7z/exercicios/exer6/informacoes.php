<?php 

$nome = $_GET['nome'];
$idade = $_GET['idade'];
$endereco = $_GET['end'];
$email = $_GET['email'];

echo "Dados do Aluno: <br>";
echo "Nome: $nome<br>";
echo "Idade: $idade<br>";
echo "Endereço: $endereco<br>";
echo "E-mail: $email<br>";


 ?>