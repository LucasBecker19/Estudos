<!DOCTYPE html>
<html>
<head>
	<title>Exercício 6</title>
	<meta charset="utf-8">
</head>
<body>
	<form method="GET" action="informacoes.php">
		<h2>Preencha as informações abaixo:</h2><br>
		Digite seu nome: <input type="text" name="nome" required=""><br>
		Digite sua idade: <input type="number" name="idade" required=""><br>
		Digite o seu endereço: <input type="text" name="end" required=""><br>
		Digite o seu e-mail: <input type="text" name="email" required=""> <br><br>
			<input type="submit" name="btn_enviar" value="Enviar">
	</form>

</body>
</html>