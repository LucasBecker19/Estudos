<?php 

$n1 = $_GET['n1'];
$n2 = $_GET['n2'];
$n3 = $_GET['n3'];
$dividir= $n1/$n2/$n3;
echo "A Divisão dos números $n1/$n2/$n3 é: $dividir";

 ?>