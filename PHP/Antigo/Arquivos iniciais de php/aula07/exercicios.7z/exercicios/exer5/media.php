<?php 

$n1= $_GET['n1'];
$n2= $_GET['n2'];
$media = ($n1+$n2)/2;
echo "A média entre os números $n1 e $n2 é: $media";


 ?>