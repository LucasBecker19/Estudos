<?php 

$salario = $_GET['salario'];
$imposto = $salario *0.2;
echo "Seu salario é: R$ $salario e você pagará de imposto o total de R$ $imposto";



 ?>