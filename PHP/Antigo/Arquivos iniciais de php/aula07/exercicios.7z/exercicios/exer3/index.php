<!DOCTYPE html>
<html>
<head>
	<title>Exercício 3</title>
	<meta charset="utf-8">
</head>
<body>
<form method="GET" action="subtrair.php">
	<h2>Subtrair três números</h2>
	Digite o primeiro número: <input type="text" name="n1" required=""><br>
	Digite o segundo número: <input type="text" name="n2" required=""><br>
	Digite o terceiro número: <input type="text" name="n3" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">
	</form>
</body>
</html>