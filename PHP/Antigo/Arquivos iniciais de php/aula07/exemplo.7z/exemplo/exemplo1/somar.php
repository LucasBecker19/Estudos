<?php 

$n1=$_GET['n1'];
$n2=$_GET['n2'];
$soma= $n1+$n2;

echo "Querido Usuário, a soma dos números $n1 e $n2 é: $soma";

 ?>