<!DOCTYPE html>
<html>
<head>
	<title>Somar dois números</title>
	<meta charset="utf-8">
</head>
<body>
	<form method="GET" action="somar.php">
	
	<h3> Somar dois números </h3> <br><br>
	Digite o primeiro número: <input type="text" name="n1" required=""><br>
	Digite o segundo número: <input type="text" name="n2" required=""><br><br>
	<input type="submit" name="btn_enviar" value="Enviar">

	</form>
</body>
</html>