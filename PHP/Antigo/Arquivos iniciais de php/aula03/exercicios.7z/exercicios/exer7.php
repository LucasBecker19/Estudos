<?php 
$salario = 3000.00;
$imposto = $salario * 0.2;

echo "<h1> Cálculo do Imposto <br> </h1>";
echo "Salario: $salario <br>";
echo "Percentual: 0.2 <br>";
echo "Imposto a pagar: $imposto";





 ?>