<?php 

$n1 = 2;
$n2 = 3;

$media = ($n1 + $n2) / 2;

echo "<h2>Média de dois números <br> </h2>";
echo "Número 1: $n1<br>";
echo "Número 2: $n2<br>";
echo "A média dos doi números é: $media";


 ?>