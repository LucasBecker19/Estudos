<?php 

$n1 = 12;
$n2 = 32;
$n3 = -5;

$soma = $n1 + $n2 + $n3;

echo "<h2>Soma de três números<br> </h2>";
echo "Número 1: $n1<br>";
echo "Número 2: $n2<br>";
echo "Número 3: $n3<br>";
echo "Soma dos três números é: $soma";






 ?>