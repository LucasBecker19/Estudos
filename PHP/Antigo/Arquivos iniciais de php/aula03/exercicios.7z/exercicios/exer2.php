
<?php 

$n1 = 2;
$n2 = 3;
$n3 = 2;

$multiplicacao = $n1 * $n2 * $n3;

echo "<h2>Multiplicação de três números <br> </h2>";
echo "Número 1: $n1<br>";
echo "Número 2: $n2<br>";
echo "Número 3: $n3<br>";
echo "Multiplicação dos três números é: $multiplicacao";


 ?>