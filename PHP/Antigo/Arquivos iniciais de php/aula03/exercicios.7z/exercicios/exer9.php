<?php 

$n1 = 5;
$n2 = 2;

echo "O resto inteiro da divisão é: ".($n1%$n2);



 ?>