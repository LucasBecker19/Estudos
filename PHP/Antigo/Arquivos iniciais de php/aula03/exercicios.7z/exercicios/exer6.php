<?php 

$nome = 'jose da silva junior';
$idade = 32;
$endereco = 'rua x numero 23 apto 12';
$email = 'jose@gmail.com';

echo "<h1>Informações do Aluno<br></h1>";
echo $nome;
echo "<br>";
echo $idade;
echo "<br>";
echo $endereco;
echo "<br>";
echo $email;






 ?>