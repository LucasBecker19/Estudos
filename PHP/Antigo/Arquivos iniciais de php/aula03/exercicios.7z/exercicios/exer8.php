<?php 


$n1 = 10;
$n2 = 20;

$soma = $n1+$n2;
$subtracao = $n1-$n2;
$multiplicacao= $n1*$n2;
$divisao= $n1/$n2;

echo "<h1> Operações Básicas <br></h1>";
echo "N1: $n1 <br>";
echo "N2: $n2 <br>";
echo "N1 + N2 = $soma <br>";
echo "N1 - N2 = $subtracao <br>";
echo "N1 * N2 = $multiplicacao <br>";
echo "N1 / N2 = $divisao <br>";



 ?>