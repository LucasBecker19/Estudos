<html>
<head>
	<title>Utilizando operações matemáticas</title>
	<meta charset="utf-8">
</head>
<body>
	<form method="POST" action="arredondamentos.php">
Digite um numero real: <input type="text" name="n1" required="" > <br><br>
<input type="submit" name="btn_enviar" value="Enviar">
<input type="reset" name="btn_limp
ar" value="Limpar Formulário">
</form>

</body>
</html>