<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST" action="calcularraiz.php" >
		Digite o primeiro número: <input type="text" name="n1" required=""><br>
		Digite o segundo número: <input type="text" name="n2" required=""><br>
		Digite o terceiro número: <input type="text" name="n3" required=""><br><br>
		<input type="submit" name="btn_enviar" value="Enviar">
		<input type="reset" name="btn_apagar" value="Apagar">


	</form>

</body>
</html>