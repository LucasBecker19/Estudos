<?php 


$n1 = $_POST['n1'];
$n2 = $_POST['n2'];
$n3 = $_POST['n3'];


echo "Primeiro Número: $n1 <br>";
echo "Raiz quadrada do primeiro Número: ".sqrt($n1)."<br>";
echo "Raiz quadrada do primeiro Número: ".number_format(sqrt($n1),0)."<br>";

echo "Segundo Número: $n2 <br>";
echo "Raiz quadrada do primeiro Número: ".sqrt($n2)."<br>";
echo "Raiz quadrada do primeiro Número: ".number_format(sqrt($n2),0)."<br>";

echo "Terceiro Número: $n3 <br>";
echo "Raiz quadrada do primeiro Número: ".sqrt($n3)."<br>";
echo "Raiz quadrada do primeiro Número: ".number_format(sqrt($n3),0)."<br>";




 ?>