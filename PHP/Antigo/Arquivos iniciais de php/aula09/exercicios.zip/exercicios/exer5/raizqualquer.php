<?php 

$numero = $_POST['n1'];
$expoente = $_POST['expoente'];


echo "A raiz no expoente $expoente do número $numero é: ".pow($numero,1/$expoente)."<br>";




 ?>