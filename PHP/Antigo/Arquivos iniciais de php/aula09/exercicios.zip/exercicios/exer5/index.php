<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST" action="raizqualquer.php" >
		
		Digite o número: <input type="number" name="n1" required=""><br>
		Digite o expoente da raiz: <input type="number" name="expoente" required=""><br><br>
		<input type="submit" name="btn_enviar" value="Enviar">
		<input type="reset" name="btn_apagar" value="Apagar">


	</form>

</body>
</html>